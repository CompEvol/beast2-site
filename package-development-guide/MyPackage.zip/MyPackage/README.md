This is my [BEAST 2](http://beast2.org) package
